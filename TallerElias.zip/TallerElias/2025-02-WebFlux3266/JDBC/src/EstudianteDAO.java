import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class EstudianteDAO {

    public void insertar(Estudiante e) {
        String sql = "INSERT INTO estudiantes(nombre, apellido, correo, edad, estado_civil) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, e.getNombre());
            stmt.setString(2, e.getApellido());
            stmt.setString(3, e.getCorreo());
            stmt.setInt(4, e.getEdad());
            stmt.setString(5, e.getEstadoCivil());
            stmt.executeUpdate();
            System.out.println(" Estudiante insertado correctamente");
        } catch (SQLException ex) {
            System.out.println(" Error insertando estudiante: " + ex.getMessage());
        }
    }

    public void actualizar(Estudiante e) {
        String sql = "UPDATE estudiantes SET nombre=?, apellido=?, edad=?, estado_civil=? WHERE correo=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, e.getNombre());
            stmt.setString(2, e.getApellido());
            stmt.setInt(3, e.getEdad());
            stmt.setString(4, e.getEstadoCivil());
            stmt.setString(5, e.getCorreo());
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println(" Estudiante actualizado correctamente");
            } else {
                System.out.println("⚠ No se encontró estudiante con ese correo");
            }
        } catch (SQLException ex) {
            System.out.println(" Error actualizando estudiante: " + ex.getMessage());
        }
    }

    public void eliminar(String correo) {
        String sql = "DELETE FROM estudiantes WHERE correo=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, correo);
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println(" Estudiante eliminado correctamente");
            } else {
                System.out.println(" No se encontró estudiante con ese correo");
            }
        } catch (SQLException ex) {
            System.out.println(" Error eliminando estudiante: " + ex.getMessage());
        }
    }

    public List<Estudiante> listarTodos() {
        List<Estudiante> lista = new ArrayList<>();
        String sql = "SELECT * FROM estudiantes";
        try (Connection conn = ConexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Estudiante(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("correo"),
                        rs.getInt("edad"),
                        rs.getString("estado_civil")
                ));
            }
        } catch (SQLException ex) {
            System.out.println(" Error listando estudiantes: " + ex.getMessage());
        }
        return lista;
    }

    public Estudiante buscarPorCorreo(String correo) {
        String sql = "SELECT * FROM estudiantes WHERE correo=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, correo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Estudiante(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("correo"),
                        rs.getInt("edad"),
                        rs.getString("estado_civil")
                );
            }
        } catch (SQLException ex) {
            System.out.println(" Error buscando estudiante: " + ex.getMessage());
        }
        return null;
    }



}
