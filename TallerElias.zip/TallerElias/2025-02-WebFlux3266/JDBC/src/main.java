import java.util.List;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        EstudianteDAO dao = new EstudianteDAO();
        Scanner sc = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("\n--- MENÚ ---");
            System.out.println("1. Insertar Estudiante");
            System.out.println("2. Actualizar Estudiante");
            System.out.println("3. Eliminar Estudiante");
            System.out.println("4. Consultar todos los Estudiantes");
            System.out.println("5. Consultar Estudiante por correo");
            System.out.println("6. Salir");
            System.out.print("Opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Apellido: ");
                    String apellido = sc.nextLine();
                    System.out.print("Correo: ");
                    String correo = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Estado civil (SOLTERO, CASADO, VIUDO, UNION_LIBRE, DIVORCIADO): ");
                    String estado = sc.nextLine();
                    dao.insertar(new Estudiante(nombre, apellido, correo, edad, estado));
                    break;

                case 2:
                    System.out.print("Correo del estudiante a actualizar: ");
                    String correoActualizar = sc.nextLine();
                    System.out.print("Nuevo nombre: ");
                    String nuevoNombre = sc.nextLine();
                    System.out.print("Nuevo apellido: ");
                    String nuevoApellido = sc.nextLine();
                    System.out.print("Nueva edad: ");
                    int nuevaEdad = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nuevo estado civil: ");
                    String nuevoEstado = sc.nextLine();
                    dao.actualizar(new Estudiante(nuevoNombre, nuevoApellido, correoActualizar, nuevaEdad, nuevoEstado));
                    break;

                case 3:
                    System.out.print("Correo del estudiante a eliminar: ");
                    String correoEliminar = sc.nextLine();
                    dao.eliminar(correoEliminar);
                    break;

                case 4:
                    List<Estudiante> estudiantes = dao.listarTodos();
                    estudiantes.forEach(System.out::println);
                    break;

                case 5:
                    System.out.print("Correo a buscar: ");
                    String correoBuscar = sc.nextLine();
                    Estudiante e = dao.buscarPorCorreo(correoBuscar);
                    if (e != null) {
                        System.out.println(e);
                    } else {
                        System.out.println(" No se encontró estudiante con ese correo");
                    }
                    break;

                case 6:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida");
            }
        } while (opcion != 6);

        sc.close();
    }

}
